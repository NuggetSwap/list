self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "99e190a8ad60cbe4d408c8a75c15d23c",
    "url": "/index.html"
  },
  {
    "revision": "22979cc8ab0ee0dd6dd7",
    "url": "/static/css/main.7e6cab28.chunk.css"
  },
  {
    "revision": "d19defed9aa9f0582772",
    "url": "/static/js/0.c3bb6e09.chunk.js"
  },
  {
    "revision": "9ea1f090d33f6446338e",
    "url": "/static/js/10.811da797.chunk.js"
  },
  {
    "revision": "02edbd72274e2abc902a",
    "url": "/static/js/11.a774972f.chunk.js"
  },
  {
    "revision": "0acb76dc93a85912d9f4",
    "url": "/static/js/3.eb3de9f6.chunk.js"
  },
  {
    "revision": "15723851b11509ef1b9a8dbd2a0ef589",
    "url": "/static/js/3.eb3de9f6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "21202e4792d276e93729",
    "url": "/static/js/4.cd0be7aa.chunk.js"
  },
  {
    "revision": "06d7268cf7468b76f8fd",
    "url": "/static/js/5.e0c86cf1.chunk.js"
  },
  {
    "revision": "374658371e5d9c95e00ea15067d24dad",
    "url": "/static/js/5.e0c86cf1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0737ceaaf6e91089a8d1",
    "url": "/static/js/6.8efdbe27.chunk.js"
  },
  {
    "revision": "88e5053053539c8b4a53480943cb0e08",
    "url": "/static/js/6.8efdbe27.chunk.js.LICENSE.txt"
  },
  {
    "revision": "74fc1e6284bef1fb11c1",
    "url": "/static/js/7.a9c62310.chunk.js"
  },
  {
    "revision": "7ec01595672f75e83fd81b41f132f4c1",
    "url": "/static/js/7.a9c62310.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5b142f8d8f688f128578",
    "url": "/static/js/8.a72f1005.chunk.js"
  },
  {
    "revision": "d43bcb65c23262ca7bd991f5625a0c00",
    "url": "/static/js/8.a72f1005.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eabf6f7bddee07759ae9",
    "url": "/static/js/9.09c40e0f.chunk.js"
  },
  {
    "revision": "22979cc8ab0ee0dd6dd7",
    "url": "/static/js/main.ed6078d6.chunk.js"
  },
  {
    "revision": "3606efcbb82f480f8f99",
    "url": "/static/js/runtime-main.91ed681e.js"
  },
  {
    "revision": "020519debb65a75d7330b4e1e1368807",
    "url": "/static/media/logo.020519de.png"
  },
  {
    "revision": "c06f3a3e804ebc7343949fdca3fdd7f8",
    "url": "/static/media/metamask-fox.c06f3a3e.svg"
  },
  {
    "revision": "020519debb65a75d7330b4e1e1368807",
    "url": "/static/media/uniswap.020519de.png"
  }
]);