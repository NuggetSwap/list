self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cef377ed7bf78dca77f1a17e86c2db94",
    "url": "./index.html"
  },
  {
    "revision": "20930e2ef8cce1822df9",
    "url": "./static/css/4.50403f6d.chunk.css"
  },
  {
    "revision": "e116827f1190e488eea3",
    "url": "./static/css/main.8f282a03.chunk.css"
  },
  {
    "revision": "bcd9c36a5c125655e6cf",
    "url": "./static/js/0.0e9eb754.chunk.js"
  },
  {
    "revision": "2dcca5009cd13e570af3fc122d60664e",
    "url": "./static/js/0.0e9eb754.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3f09d484b418949f0742",
    "url": "./static/js/1.17714ae9.chunk.js"
  },
  {
    "revision": "20930e2ef8cce1822df9",
    "url": "./static/js/4.0843ca0d.chunk.js"
  },
  {
    "revision": "b2e3aacc0098797ca3b13a5599a9a84f",
    "url": "./static/js/4.0843ca0d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4e434f09b4041252b808",
    "url": "./static/js/5.3ebaec07.chunk.js"
  },
  {
    "revision": "8d00ff20fe886564280736b6b6b8eac1",
    "url": "./static/js/5.3ebaec07.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e570feb9b2c352733126",
    "url": "./static/js/6.221f3311.chunk.js"
  },
  {
    "revision": "086ac0f260c0d88cf399717695349565",
    "url": "./static/js/6.221f3311.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c9cd6ea382f00519a621",
    "url": "./static/js/7.244c6a26.chunk.js"
  },
  {
    "revision": "82e8dc64c1183f0e44dc",
    "url": "./static/js/8.c336c71d.chunk.js"
  },
  {
    "revision": "c178649ae0de162657ef6caa733cc024",
    "url": "./static/js/8.c336c71d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3b79f3b43362c9e3b262",
    "url": "./static/js/9.93e7125c.chunk.js"
  },
  {
    "revision": "e116827f1190e488eea3",
    "url": "./static/js/main.e5593908.chunk.js"
  },
  {
    "revision": "8bd1897d395912b72367",
    "url": "./static/js/runtime-main.96929ca2.js"
  },
  {
    "revision": "661569afe57a38e1529a775a465da20b",
    "url": "./static/media/Inter-Black.661569af.woff2"
  },
  {
    "revision": "d0b121f3a9d3d88afdfd6902d31ee9a0",
    "url": "./static/media/Inter-Black.d0b121f3.woff"
  },
  {
    "revision": "a3cc36c89047d530522fc999a22cce54",
    "url": "./static/media/Inter-BlackItalic.a3cc36c8.woff2"
  },
  {
    "revision": "e3329b2b90e1f9bcafd4a36604215dc1",
    "url": "./static/media/Inter-BlackItalic.e3329b2b.woff"
  },
  {
    "revision": "444a7284663a3bc886683eb81450b294",
    "url": "./static/media/Inter-Bold.444a7284.woff2"
  },
  {
    "revision": "99a0d9a7e4c99c17bfdd94a22a5cf94e",
    "url": "./static/media/Inter-Bold.99a0d9a7.woff"
  },
  {
    "revision": "3aa31f7356ea9db132b3b2bd8a65df44",
    "url": "./static/media/Inter-BoldItalic.3aa31f73.woff"
  },
  {
    "revision": "96284e2a02af46d9ffa2d189eaad5483",
    "url": "./static/media/Inter-BoldItalic.96284e2a.woff2"
  },
  {
    "revision": "37da9eecf61ebced804b266b14eef98e",
    "url": "./static/media/Inter-ExtraBold.37da9eec.woff2"
  },
  {
    "revision": "ab70688a1c9d6525584b123575f6c0a5",
    "url": "./static/media/Inter-ExtraBold.ab70688a.woff"
  },
  {
    "revision": "728a4c7df3ed1b2bc077010063f9ef1c",
    "url": "./static/media/Inter-ExtraBoldItalic.728a4c7d.woff"
  },
  {
    "revision": "fcc7d60ef790b43eb520fdc5c7348799",
    "url": "./static/media/Inter-ExtraBoldItalic.fcc7d60e.woff2"
  },
  {
    "revision": "b3b2ed6a20c538e9c809f4df5c04ac2a",
    "url": "./static/media/Inter-ExtraLight.b3b2ed6a.woff2"
  },
  {
    "revision": "dd19efda9c6e88ad83a5b052915899f7",
    "url": "./static/media/Inter-ExtraLight.dd19efda.woff"
  },
  {
    "revision": "079cd1e71cd4f73bef86f72deced6d03",
    "url": "./static/media/Inter-ExtraLightItalic.079cd1e7.woff2"
  },
  {
    "revision": "a6566ae6fa3c58b48f888d7c9c234d52",
    "url": "./static/media/Inter-ExtraLightItalic.a6566ae6.woff"
  },
  {
    "revision": "f137a90d649b6ab032563856df323f40",
    "url": "./static/media/Inter-Italic.f137a90d.woff"
  },
  {
    "revision": "fd26ff23f831db9ae85a805386529385",
    "url": "./static/media/Inter-Italic.fd26ff23.woff2"
  },
  {
    "revision": "5d3776eb78374b0ebbce639adadf73d1",
    "url": "./static/media/Inter-Light.5d3776eb.woff"
  },
  {
    "revision": "780dd2adb71f18d7a357ab7f65e881d6",
    "url": "./static/media/Inter-Light.780dd2ad.woff2"
  },
  {
    "revision": "d0fa7cbcf9ca5edb6ebe41fd8d49e1fb",
    "url": "./static/media/Inter-LightItalic.d0fa7cbc.woff"
  },
  {
    "revision": "df29c53403b2e13dc56df3e291c32f09",
    "url": "./static/media/Inter-LightItalic.df29c534.woff2"
  },
  {
    "revision": "75db5319e7e87c587019a5df08d7272c",
    "url": "./static/media/Inter-Medium.75db5319.woff2"
  },
  {
    "revision": "c0638bea87a05fdfa2bb3bba2efe54e4",
    "url": "./static/media/Inter-Medium.c0638bea.woff"
  },
  {
    "revision": "a1b588627dd12c556a7e3cd81e400ecf",
    "url": "./static/media/Inter-MediumItalic.a1b58862.woff"
  },
  {
    "revision": "f1e11535e56c67698e263673f625103e",
    "url": "./static/media/Inter-MediumItalic.f1e11535.woff2"
  },
  {
    "revision": "3ac83020fe53b617b79b5e2ad66764af",
    "url": "./static/media/Inter-Regular.3ac83020.woff"
  },
  {
    "revision": "dc131113894217b5031000575d9de002",
    "url": "./static/media/Inter-Regular.dc131113.woff2"
  },
  {
    "revision": "007ad31a53f4ab3f58ee74f2308482ce",
    "url": "./static/media/Inter-SemiBold.007ad31a.woff2"
  },
  {
    "revision": "66a68ffab2bf40553e847e8f025f75be",
    "url": "./static/media/Inter-SemiBold.66a68ffa.woff"
  },
  {
    "revision": "3031b683bafcd9ded070c00d784f4626",
    "url": "./static/media/Inter-SemiBoldItalic.3031b683.woff2"
  },
  {
    "revision": "6cd13dbd150ac0c7f337a2939a3d50a8",
    "url": "./static/media/Inter-SemiBoldItalic.6cd13dbd.woff"
  },
  {
    "revision": "b068b7189120a6626e3cfe2a8b917d0f",
    "url": "./static/media/Inter-Thin.b068b718.woff"
  },
  {
    "revision": "d52e5e38715502616522eb3e9963b69b",
    "url": "./static/media/Inter-Thin.d52e5e38.woff2"
  },
  {
    "revision": "97bec98832c92f799aeebf670b83ff6c",
    "url": "./static/media/Inter-ThinItalic.97bec988.woff"
  },
  {
    "revision": "a9780071b7f498c1523602910a5ef242",
    "url": "./static/media/Inter-ThinItalic.a9780071.woff2"
  },
  {
    "revision": "1f7ca6383ea7c74a7f5ddd76c3d3cef2",
    "url": "./static/media/Inter-italic.var.1f7ca638.woff2"
  },
  {
    "revision": "66c6e40883646a7ad993108b2ce2da32",
    "url": "./static/media/Inter-roman.var.66c6e408.woff2"
  },
  {
    "revision": "8dd26c3dd0125fb16ce19b8f5e8273fb",
    "url": "./static/media/Inter.var.8dd26c3d.woff2"
  },
  {
    "revision": "cd061363bbf9cd7a26cb09b642dcaf63",
    "url": "./static/media/arrow-down-blue.cd061363.svg"
  },
  {
    "revision": "c0dedd2f2ed0c4d07d7ca75af3f0a65f",
    "url": "./static/media/arrow-down-grey.c0dedd2f.svg"
  },
  {
    "revision": "337ad716bd89163e2a9c3495b7e0f029",
    "url": "./static/media/arrow-right-white.337ad716.png"
  },
  {
    "revision": "d285b6cf22b4f1552bb4009333462632",
    "url": "./static/media/arrow-right.d285b6cf.svg"
  },
  {
    "revision": "14691cace8747bb932f3e23ffeacaad0",
    "url": "./static/media/bg01.14691cac.jpg"
  },
  {
    "revision": "904b44c2b22eb2d49f618396e6f2db1a",
    "url": "./static/media/blue-loader.904b44c2.svg"
  },
  {
    "revision": "3af63018071dc72f01ff1880304ea6ec",
    "url": "./static/media/bnb.3af63018.svg"
  },
  {
    "revision": "ed2a1dad16cb9a4b9afd788ddaae7290",
    "url": "./static/media/circle-grey.ed2a1dad.svg"
  },
  {
    "revision": "2d975615c4c409c3b6b00e8ae7c5767a",
    "url": "./static/media/circle.2d975615.svg"
  },
  {
    "revision": "62578f5994645a1825d4829e2c4394b0",
    "url": "./static/media/coinbaseWalletIcon.62578f59.svg"
  },
  {
    "revision": "b0bb8ec4fd1b612767601f7c84317e53",
    "url": "./static/media/darkBG01.b0bb8ec4.png"
  },
  {
    "revision": "b20914ec5482543a0b1b2c6d5509ab96",
    "url": "./static/media/dropdown-blue.b20914ec.svg"
  },
  {
    "revision": "7d32d2fa19d17d6ab9f0e0067bebaf96",
    "url": "./static/media/dropdown.7d32d2fa.svg"
  },
  {
    "revision": "b96d70e10dd30a64a0d122603577c8ae",
    "url": "./static/media/dropup-blue.b96d70e1.svg"
  },
  {
    "revision": "ccd4192c013d052de1db1ae7dd68f081",
    "url": "./static/media/favicon.ccd4192c.ico"
  },
  {
    "revision": "9470ce8e8bd4af90b8fa0605e8fbad42",
    "url": "./static/media/fighter-icon.9470ce8e.png"
  },
  {
    "revision": "50c67f3cdd04281013ef95e92fc7244e",
    "url": "./static/media/link.50c67f3c.svg"
  },
  {
    "revision": "020519debb65a75d7330b4e1e1368807",
    "url": "./static/media/logo.020519de.png"
  },
  {
    "revision": "020519debb65a75d7330b4e1e1368807",
    "url": "./static/media/logo_white.020519de.png"
  },
  {
    "revision": "674400972753804891ec372652944539",
    "url": "./static/media/magnifying-glass.67440097.svg"
  },
  {
    "revision": "fb35b33c0cf47f223d9365739664076e",
    "url": "./static/media/mathwallet.fb35b33c.svg"
  },
  {
    "revision": "4f2c4440e19ed9428d0caae5d9840df6",
    "url": "./static/media/menu.4f2c4440.svg"
  },
  {
    "revision": "023762b6aec2a2249b8fdfb638f00ef3",
    "url": "./static/media/metamask.023762b6.png"
  },
  {
    "revision": "e8021e51723d455b2f9fa2446808d2a3",
    "url": "./static/media/plus-blue.e8021e51.svg"
  },
  {
    "revision": "d8e0be7d6efb0b53c37eb75e44b35bda",
    "url": "./static/media/plus-grey.d8e0be7d.svg"
  },
  {
    "revision": "b234b2bfa0417c7e8711c3a8d17afeec",
    "url": "./static/media/portisIcon.b234b2bf.png"
  },
  {
    "revision": "1ae4d9f4653371789d98b85139933d27",
    "url": "./static/media/question-mark.1ae4d9f4.svg"
  },
  {
    "revision": "a46e8bc1a36444be83a85007353d692f",
    "url": "./static/media/question.a46e8bc1.svg"
  },
  {
    "revision": "be00fc4a29d03016e78b28c9943e3f51",
    "url": "./static/media/spinner.be00fc4a.svg"
  },
  {
    "revision": "09a84ca1a569a1bb6bebd08d9c0347aa",
    "url": "./static/media/sprite.09a84ca1.png"
  },
  {
    "revision": "edcc1ab5dde5cb3d5cf134c4aade641b",
    "url": "./static/media/trustWallet.edcc1ab5.png"
  },
  {
    "revision": "eebf3ae254646c3889f203cc88345ac3",
    "url": "./static/media/trustwallet.eebf3ae2.svg"
  },
  {
    "revision": "8215855c185176eb79446ce8cc1f3998",
    "url": "./static/media/walletConnectIcon.8215855c.svg"
  },
  {
    "revision": "5b8e218668bfea1d44b887bd042f6a52",
    "url": "./static/media/x.5b8e2186.svg"
  }
]);